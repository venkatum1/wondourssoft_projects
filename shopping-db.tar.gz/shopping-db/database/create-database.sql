-- Create a new, empty database

CREATE DATABASE shopping WITH OWNER=customer;
